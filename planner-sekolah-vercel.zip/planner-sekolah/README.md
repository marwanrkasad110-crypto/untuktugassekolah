# Planner Sekolah

Aplikasi web sederhana untuk jadwal Senin–Jumat dan daftar tugas.

## Fitur
- Tambah, ubah, dan hapus pelajaran per hari.
- Simpan jam mulai dan selesai.
- Tambah tugas, deadline, dan waktu pengingat.
- Tandai tugas selesai.
- Penyimpanan lokal browser (`localStorage`).
- PWA sederhana dengan cache agar bisa dibuka offline setelah kunjungan online pertama.
- Siap di-deploy sebagai static site di Vercel.

## Jalankan lokal
Buka folder ini dengan server lokal, misalnya:
`python -m http.server 8000`
Lalu buka `http://localhost:8000`.

## Deploy ke Vercel
1. Unggah folder proyek ini ke repository GitHub.
2. Masuk ke Vercel dan pilih **Add New → Project**.
3. Import repository tersebut.
4. Framework Preset: **Other**. Build Command dan Output Directory dapat dikosongkan/default.
5. Deploy.

## Catatan penyimpanan dan offline
Data disimpan di browser/perangkat yang digunakan. Data tidak otomatis tersinkron ke perangkat lain dan bisa hilang jika data situs/browser dihapus. Gunakan browser dan perangkat yang sama. Buka aplikasi sekali saat online agar service worker menyimpan file aplikasi untuk penggunaan offline.

## Catatan notifikasi
Notifikasi pada versi ini diperiksa selama halaman aplikasi sedang terbuka. Notifikasi terjadwal yang tetap berjalan ketika browser benar-benar ditutup membutuhkan backend/push service dan konfigurasi tambahan.